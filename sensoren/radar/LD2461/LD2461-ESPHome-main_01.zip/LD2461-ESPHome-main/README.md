# LD2461-ESPHome
 ESPHome for HiLink LD-2461 mmWave sensor

 UNDER DEVELOPMENT
